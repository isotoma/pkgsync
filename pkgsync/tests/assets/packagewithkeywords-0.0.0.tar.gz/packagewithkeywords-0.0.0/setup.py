from setuptools import setup, find_packages

setup(
    name='packagewithkeywords',
    version='0.0.0',
    packages=find_packages(exclude=['ez_setup', 'examples', 'tests']),
    include_package_data=True,
    zip_safe=False,
    keywords='testing space separated keywords',
)

print 'hi'

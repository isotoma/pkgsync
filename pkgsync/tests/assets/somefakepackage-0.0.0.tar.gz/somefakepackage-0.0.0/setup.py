from setuptools import setup, find_packages

setup(
    name='somefakepackage',
    version='0.0.0',
    author='Eddy Merckx',
    author_email='eddy.merckx@isotoma.com',
    description='Package description',
    long_description='Long package description.',
    packages=find_packages(exclude=['ez_setup', 'examples', 'tests']),
    include_package_data=True,
    zip_safe=False,
    install_requires=[
        'setuptools',
    ],
)
